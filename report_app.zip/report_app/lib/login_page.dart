import 'package:flutter/material.dart'; // Gives you access to widgets such as scaffold, text etc.
import 'package:flutter_svg/flutter_svg.dart';
import 'Reporting.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  String email = '';
  String password = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 75,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              'assets/images/logo_placeholder.jpg',
              height: 100,
              width: 100,
            ),
          ],
        ),
        centerTitle: true,
        backgroundColor: Colors.red,
        leading: GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    const ReportingPage(), // CHANGE LOGIN PAGE TO HOME PAGE
              ),
            );
          },
          child: Container(
            margin: EdgeInsets.all(12),
            alignment: Alignment.center, // This makes the icon smaller
            child: SvgPicture.asset('assets/icons/back_arrow.svg'),
            decoration: BoxDecoration(
              color: Color(0xffF7F8F8), // colour of the box
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
      ),

      body: Column(
        children: [
          Text(
            "\nWelcome to Login",
            style: TextStyle(color: Colors.black, fontSize: 30),
          ),
          Text(
            "\n \n Email:",
            style: TextStyle(color: Colors.black, fontSize: 17),
          ),
          Container(
            margin: EdgeInsets.only(
              top: 10,
              left: 30,
              right: 30,
            ), // How far away from the top and sides you want it, makes it small/big in width
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Color(
                    0xff1D1617,
                  ).withValues(alpha: 0.11), // Implementing a shadow to the box
                  blurRadius: 40,
                  spreadRadius: 0.0,
                ),
              ],
            ),
            child: TextField(
              controller: emailController,
              decoration: InputDecoration(
                hintText: "example@gmail.com",
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    15,
                  ), // curves the edges of the box
                  borderSide: BorderSide
                      .none, // removes the line at the bottom of the text box
                ),
              ),
            ),
          ),

          Text(
            "\n \n Password:",
            style: TextStyle(color: Colors.black, fontSize: 17),
          ),
          Container(
            margin: EdgeInsets.only(top: 10, left: 30, right: 30),
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Color(
                    0xff1D1617,
                  ).withValues(alpha: 0.11), // Implementing a shadow to the box
                  blurRadius: 40,
                  spreadRadius: 0.0,
                ),
              ],
            ),
            child: TextField(
              controller: passwordController,
              decoration: InputDecoration(
                hintText: "Password",
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    15,
                  ), // curves the edges of the box
                  borderSide: BorderSide
                      .none, // removes the line at the bottom of the text box
                ),
              ),
            ),
          ),

          TextButton(
            onPressed: () {
              print("Reset Password");
            },
            child: Text(
              'Forgot Password',
              style: TextStyle(color: Colors.blue),
            ),
          ),

          ElevatedButton(
            onPressed: () {
              email = emailController.text;
              password = passwordController.text;
            },
            child: Text('Login', style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
    ); // Scaffold allows for different tools to be implemented such as a appbar, bottombar, floating button
  }
}
