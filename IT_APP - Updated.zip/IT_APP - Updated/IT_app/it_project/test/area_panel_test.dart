import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:it_project/Pages/Home.dart';
import 'package:it_project/Pages/auth_store.dart';

void main() {
  setUp(() {
    AuthStore.registerUser(
      name: 'Shalin',
      surname: 'Govender',
      username: 'shalin',
      email: 'shaling357@gmail.com',
      password: 'Smg_22@7',
    );
  });

  testWidgets(
    'Area detail view shows report button and auto-added user in chat',
    (tester) async {
      await tester.pumpWidget(
        const MaterialApp(home: AreaDetailPage(areaName: 'Area 2')),
      );

      expect(
        find.widgetWithText(ElevatedButton, 'Reports for Area 2'),
        findsOneWidget,
      );
      expect(find.text('Chat room • Area 2'), findsOneWidget);
      expect(find.textContaining('Shalin'), findsWidgets);
    },
  );
}
