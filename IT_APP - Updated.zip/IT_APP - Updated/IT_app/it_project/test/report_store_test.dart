import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:it_project/Pages/auth_store.dart';
import 'package:it_project/Pages/report_store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    await ReportStore.initialize();
    AuthStore.registerUser(
      name: 'Test',
      surname: 'User',
      username: 'tester',
      email: 'tester@example.com',
      password: 'Pass1234',
    );
  });

  test('offline report tracks creation and submission timestamps', () async {
    ReportStore.setConnectionStatus(false);

    final report = ReportStore.addReport(
      issueType: 'Water and Sanitation',
      issue: 'Burst Pipe',
      area: 'Durban',
      description: 'Pipe leaking',
      locationAddress: '20 Main Rd',
      pinLocation: 'GPS-1',
      imagePath: '',
      isOfflineSubmission: true,
    );

    expect(report, isNotNull);
    expect(report!.createdAt, isNotNull);
    expect(report.queuedAt, isNotNull);
    expect(report.submittedAt, isNull);
    expect(report.storageType, 'offline');

    report.markSubmitted();
    expect(report.submittedAt, isNotNull);
    expect(report.syncStatus, 'Synced');
  });

  test(
    'report store exposes analytics for offline and online submissions',
    () async {
      ReportStore.setConnectionStatus(false);

      final offlineReport = ReportStore.addReport(
        issueType: 'Waste Management',
        issue: 'Illegal Dumping',
        area: 'Durban',
        description: 'Dumped waste',
        locationAddress: '10 Beach Rd',
        pinLocation: 'GPS-2',
        imagePath: '',
        isOfflineSubmission: true,
      );

      offlineReport!.markSubmitted();

      final analytics = ReportStore.analyticsSummary();

      expect(analytics['totalReports'], greaterThanOrEqualTo(1));
      expect(analytics['syncedReports'], greaterThanOrEqualTo(1));
      expect(analytics['offlineReports'], greaterThanOrEqualTo(0));
    },
  );

  test('reports are queued offline first and later synced online', () async {
    ReportStore.setConnectionStatus(true);

    final queuedReport = ReportStore.addReport(
      issueType: 'Water and Sanitation',
      issue: 'Burst Pipe',
      area: 'Cape Town',
      description: 'Main water line leaking',
      locationAddress: '15 Long Street',
      pinLocation: 'GPS-3',
      imagePath: '',
    );

    expect(queuedReport, isNotNull);
    expect(queuedReport!.storageType, 'offline');
    expect(queuedReport.syncStatus, 'Queued offline');
    expect(queuedReport.submittedAt, isNull);

    await ReportStore.syncPendingReports((report) async {
      expect(report.id, queuedReport.id);
      return true;
    });

    expect(queuedReport.storageType, 'online');
    expect(queuedReport.syncStatus, 'Synced');
    expect(queuedReport.submittedAt, isNotNull);
  });
}
