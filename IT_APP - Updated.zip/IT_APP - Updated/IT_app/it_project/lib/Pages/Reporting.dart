import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import 'CheckStatus.dart';
import 'Help.dart';
import 'auth_store.dart';
import 'worker_theme.dart';
import 'report_store.dart';

class ReportingPage extends StatefulWidget {
  const ReportingPage({super.key});

  @override
  State<ReportingPage> createState() => _ReportingPageState();
}

class _ReportingPageState extends State<ReportingPage> {
  final formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final locationController = TextEditingController();
  final pinLocationController = TextEditingController();
  final additionalInfoController = TextEditingController();
  bool _locationPermissionGranted = false;

  final issueTypes = [
    'Roads and Stormwater',
    'Electricity',
    'Water and Sanitation',
    'Waste Management',
  ];
  final roadIssues = [
    'Pothole',
    'Sinkhole',
    'Blocked Storm Drain',
    'Flooded Road',
    'Traffic Light Not Working',
  ];
  final electricityIssues = [
    'Street Light Not Working',
    'Street Light On During Day',
    'Power Outage',
    'Exposed Or Damaged Cable',
    'Damaged Electrical Box',
  ];
  final waterIssues = [
    'Burst Pipe',
    'Leaking Pipe',
    'No Water Supply',
    'Low Water Pressure',
    'Blocked Sewer or Manhole',
    'Sewage Spill',
    'Discolored or Dirty Water',
  ];
  final wasteIssues = [
    'Missed Bin Collection',
    'Illegal Dumping',
    'Overflowing Public Bin',
  ];

  String? selectedIssueType;
  String? selectedIssue;
  XFile? selectedImage;
  bool _isRemoteArea = false;

  List<String> get availableIssues {
    switch (selectedIssueType) {
      case 'Roads and Stormwater':
        return roadIssues;
      case 'Electricity':
        return electricityIssues;
      case 'Water and Sanitation':
        return waterIssues;
      case 'Waste Management':
        return wasteIssues;
      default:
        return const [];
    }
  }

  @override
  void initState() {
    super.initState();
    _refreshLocationPermissionState();
  }

  Future<void> _refreshLocationPermissionState() async {
    final status = await Permission.locationWhenInUse.status;
    if (!mounted) return;
    setState(() {
      _locationPermissionGranted = status.isGranted || status.isLimited;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isWorker = AuthStore.currentUser?.isWorker == true;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: pagePrimaryColor(isWorker: isWorker),
        title: const Text('Reporting'),
        actions: [
          IconButton(
            tooltip: 'Help',
            icon: const Icon(Icons.help_outline),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HelpPage()),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: pageBackgroundDecoration(isWorker: isWorker),
        child: Form(
          key: formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.84),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'Submit a Report',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 24),
                  DropdownButtonFormField<String>(
                    initialValue: selectedIssueType,
                    decoration: const InputDecoration(
                      labelText: 'Type of issue',
                    ),
                    items: issueTypes
                        .map(
                          (issue) => DropdownMenuItem(
                            value: issue,
                            child: Text(issue),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedIssueType = value;
                        selectedIssue = null;
                      });
                    },
                    validator: (value) => value == null
                        ? 'Please select the type of issue'
                        : null,
                  ),
                  const SizedBox(height: 14),
                  if (selectedIssueType != null)
                    DropdownButtonFormField<String>(
                      initialValue: selectedIssue,
                      decoration: const InputDecoration(
                        labelText: 'Specific issue',
                      ),
                      items: availableIssues
                          .map(
                            (issue) => DropdownMenuItem(
                              value: issue,
                              child: Text(issue),
                            ),
                          )
                          .toList(),
                      onChanged: (value) => setState(() {
                        selectedIssue = value;
                      }),
                      validator: (value) => value == null
                          ? 'Please select the specific issue'
                          : null,
                    ),
                  if (selectedIssueType != null) const SizedBox(height: 14),
                  if (_locationPermissionGranted)
                    Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.green.shade200),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.my_location, color: Colors.green),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Location permission is enabled. You may continue using location or type an address.',
                              style: TextStyle(
                                color: Colors.green,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  Row(
                    children: [
                      Expanded(
                        child: _field(
                          controller: locationController,
                          label: 'Street name / landmark',
                          validator: (value) {
                            if (_locationPermissionGranted) {
                              return null;
                            }
                            if (value == null || value.trim().isEmpty) {
                              return 'Please enter the street name or landmark';
                            }
                            return null;
                          },
                          hint: _locationPermissionGranted
                              ? 'Optional: type the address if you prefer to enter it manually'
                              : 'Type the address if you know it',
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        tooltip: _locationPermissionGranted
                            ? 'Location access is enabled'
                            : 'Open device settings to enable location access',
                        onPressed: () async {
                          final status =
                              await Permission.locationWhenInUse.status;
                          if (status.isGranted || status.isLimited) {
                            await _refreshLocationPermissionState();
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Location access is enabled.'),
                                ),
                              );
                            }
                            return;
                          }
                          await Permission.locationWhenInUse.request();
                          await _refreshLocationPermissionState();
                        },
                        icon: Icon(
                          Icons.location_on,
                          color: _locationPermissionGranted
                              ? Colors.green
                              : Colors.red,
                        ),
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.red.shade50,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SwitchListTile.adaptive(
                    contentPadding: EdgeInsets.zero,
                    value: _isRemoteArea,
                    title: const Text('Remote area'),
                    subtitle: const Text(
                      'Turn this on if the area is hard to identify by street name. A pin location is then required.',
                    ),
                    onChanged: (value) => setState(() => _isRemoteArea = value),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _field(
                          controller: pinLocationController,
                          label: _isRemoteArea
                              ? 'Pin location (required)'
                              : 'Pin location (optional)',
                          hint: _isRemoteArea
                              ? 'Add a pin reference for the remote location'
                              : 'Optional: add a pin reference if known',
                          validator: (value) {
                            if (_isRemoteArea &&
                                (value == null || value.trim().isEmpty)) {
                              return 'Please add a pin location for a remote area';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        tooltip: 'Open location settings to add a pin',
                        onPressed: _openLocationSettings,
                        icon: const Icon(Icons.location_on_outlined),
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.red.shade50,
                          foregroundColor: Colors.red,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _field(
                    controller: additionalInfoController,
                    label: 'Additional Information',
                    hint: 'Add any additional details to your report',
                  ),
                  const SizedBox(height: 14),
                  OutlinedButton.icon(
                    onPressed: _chooseImage,
                    icon: const Icon(Icons.add_a_photo_outlined),
                    label: Text(
                      selectedImage == null
                          ? 'Add Image'
                          : 'Image selected: ${selectedImage!.name}',
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(context),
                          style: OutlinedButton.styleFrom(
                            minimumSize: const Size.fromHeight(52),
                          ),
                          child: const Text('Cancel'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _submit,
                          style: ElevatedButton.styleFrom(
                            minimumSize: const Size.fromHeight(52),
                          ),
                          child: const Text('Submit'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: pagePrimaryColor(isWorker: isWorker),
        currentIndex: 1,
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const StatusPage()),
            );
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HelpPage()),
            );
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.assignment),
            label: 'Profile',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.help), label: 'Help'),
        ],
      ),
    );
  }

  Widget _field({
    required TextEditingController controller,
    required String label,
    String? Function(String?)? validator,
    String? hint,
  }) {
    return TextFormField(
      controller: controller,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: Colors.white,
        border: const OutlineInputBorder(),
      ),
    );
  }

  Future<void> _openLocationSettings() async {
    final status = await Permission.locationWhenInUse.request();
    if (!mounted) return;

    if (status.isGranted || status.isLimited) {
      pinLocationController.text = pinLocationController.text.trim().isEmpty
          ? 'Location access enabled; pin location can be added from device settings.'
          : pinLocationController.text;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Location access is enabled.')),
      );
      return;
    }

    await openAppSettings();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Open app settings to enable location access and add a pin.',
        ),
      ),
    );
  }

  Future<void> _chooseImage() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Choose from gallery'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined),
              title: const Text('Take a photo'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.camera),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;
    final image = await ImagePicker().pickImage(source: source);
    if (image != null && mounted) setState(() => selectedImage = image);
  }

  Future<void> _submit() async {
    if (!formKey.currentState!.validate()) return;
    final report = ReportStore.addReport(
      issueType: selectedIssueType!,
      issue: selectedIssue!,
      area: locationController.text,
      description: additionalInfoController.text,
      pinLocation: pinLocationController.text,
      locationAddress: locationController.text,
      imagePath: selectedImage?.path ?? '',
      isOfflineSubmission: !ReportStore.isOnline,
    );
    if (report == null) return;
    if (!mounted) return;
    final message = report.storageType == 'offline'
        ? 'Report saved offline. It will sync when the internet is available.'
        : 'Report logged and sent successfully.';
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const StatusPage()),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    locationController.dispose();
    pinLocationController.dispose();
    additionalInfoController.dispose();
    super.dispose();
  }
}
