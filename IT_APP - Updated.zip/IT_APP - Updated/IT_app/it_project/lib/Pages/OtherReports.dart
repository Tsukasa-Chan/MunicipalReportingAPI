import 'package:flutter/material.dart';

import 'CheckStatus.dart';
import 'Help.dart';
import 'auth_store.dart';
import 'worker_theme.dart';

class OtherReportsPage extends StatefulWidget {
  const OtherReportsPage({super.key, this.initialFilter = 'All'});

  final String initialFilter;

  @override
  State<OtherReportsPage> createState() => _OtherReportsPageState();
}

class _OtherReportsPageState extends State<OtherReportsPage> {
  late String selectedFilter;

  @override
  void initState() {
    super.initState();
    selectedFilter = widget.initialFilter;
  }

  final reports = [
    {
      'id': '001',
      'issue': 'Roads and Stormwater',
      'specificIssue': 'Pothole',
      'addInfo':
          'There are multiple potholes on this road, on the oncoming lanes as well',
      'location': '20 Dolphin Road',
      'date': '17/05/2026',
      'status': 'Pending',
    },
    {
      'id': '002',
      'issue': 'Roads and Stormwater',
      'specificIssue': 'Pothole',
      'addInfo': '',
      'location': '50 King Shaka Road',
      'date': '02/07/2026',
      'status': 'Pending',
    },
    {
      'id': '003',
      'issue': 'Water and Sanitation',
      'specificIssue': 'No Water Supply',
      'addInfo': 'There has been no water for 2 days',
      'location': '25 Roz Road',
      'date': '25/08/2026',
      'status': 'Pending',
    },
    {
      'id': '004',
      'issue': 'Electricity',
      'specificIssue': 'Power Outage',
      'addInfo': 'The power has been off for more than 24 hours',
      'location': '24 La Mercy Drive',
      'date': '25/08/2026',
      'status': 'Pending',
    },
    {
      'id': '005',
      'issue': 'Electricity',
      'specificIssue': 'Street Light Not Working',
      'addInfo': 'Difficult to drive at night with no street lights',
      'location': 'Old Main Road',
      'date': '25/03/2026',
      'status': 'Pending',
    },
    {
      'id': '006',
      'issue': 'Waste Management',
      'specificIssue': 'Missed Bin Collection',
      'addInfo': 'The bins have not been collected this week',
      'location': '34 Sandfields Road',
      'date': '14/07/2026',
      'status': 'Pending',
    },
    {
      'id': '007',
      'issue': 'Electricity',
      'specificIssue': 'Power Outage',
      'addInfo': '',
      'location': '23 Seatides Main Road',
      'date': '04/05/2026',
      'status': 'Pending',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final isWorker = AuthStore.currentUser?.isWorker == true;
    final filteredReports = selectedFilter == 'All'
        ? reports
        : reports.where((report) => report['issue'] == selectedFilter).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: pagePrimaryColor(isWorker: isWorker),
        title: const Text('View Other Reports'),
        actions: [
          IconButton(
            tooltip: 'Help',
            icon: const Icon(Icons.help_outline),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HelpPage()),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: pageBackgroundDecoration(isWorker: isWorker),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Community reports',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    OutlinedButton.icon(
                      onPressed: _showFilterDialog,
                      icon: const Icon(Icons.filter_list),
                      label: Text(
                        selectedFilter == 'All' ? 'Filter' : selectedFilter,
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: filteredReports.isEmpty
                    ? const Center(
                        child: Text(
                          'No reports found for this filter.',
                          style: TextStyle(color: Colors.white),
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                        itemCount: filteredReports.length,
                        itemBuilder: (context, index) =>
                            _reportCard(filteredReports[index]),
                      ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: pagePrimaryColor(isWorker: isWorker),
        currentIndex: 1,
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const StatusPage()),
            );
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HelpPage()),
            );
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.assignment),
            label: 'Status',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.help), label: 'Help'),
        ],
      ),
    );
  }

  Widget _reportCard(Map<String, String> report) {
    final issue = report['issue'] ?? 'Other';
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.fromLTRB(16, 8, 12, 8),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        leading: CircleAvatar(
          backgroundColor: _issueColor(issue),
          child: Icon(_issueIcon(issue), color: Colors.white),
        ),
        title: Text(
          'Report #${report['id']}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          report['specificIssue'] ?? issue,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        trailing: _statusChip(report['status'] ?? 'Unknown'),
        children: [
          const Divider(height: 1),
          const SizedBox(height: 12),
          _detailRow(Icons.category_outlined, 'Category', issue),
          _detailRow(
            Icons.calendar_today_outlined,
            'Submitted',
            report['date'] ?? 'Unknown',
          ),
          _detailRow(
            Icons.location_on_outlined,
            'Location',
            report['location'] ?? 'Unknown',
          ),
          _detailRow(
            Icons.notes_outlined,
            'Additional information',
            report['addInfo']?.isEmpty == true
                ? 'No additional information'
                : report['addInfo'] ?? 'No additional information',
          ),
        ],
      ),
    );
  }

  Widget _detailRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 19, color: const Color(0xFFB71C1C)),
          const SizedBox(width: 10),
          Expanded(child: Text('$label: $value')),
        ],
      ),
    );
  }

  Widget _statusChip(String status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: _statusColor(status).withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status,
        style: TextStyle(
          color: _statusColor(status),
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Resolved':
        return Colors.green.shade700;
      case 'Rejected':
        return Colors.red.shade700;
      case 'In Progress':
        return Colors.blue.shade700;
      default:
        return Colors.orange.shade800;
    }
  }

  Color _issueColor(String issue) {
    switch (issue) {
      case 'Electricity':
        return Colors.blueGrey;
      case 'Water and Sanitation':
        return Colors.blue;
      case 'Waste Management':
        return Colors.teal;
      default:
        return const Color(0xFFB71C1C);
    }
  }

  IconData _issueIcon(String issue) {
    switch (issue) {
      case 'Electricity':
        return Icons.bolt;
      case 'Water and Sanitation':
        return Icons.water_drop_outlined;
      case 'Waste Management':
        return Icons.delete_outline;
      default:
        return Icons.construction_outlined;
    }
  }

  void _showFilterDialog() {
    String temporaryFilter = selectedFilter;
    showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Filter reports'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ...[
                'All',
                ...reports.map((report) => report['issue']!).toSet(),
              ].map(
                (filter) => RadioListTile<String>(
                  title: Text(filter == 'All' ? 'All reports' : filter),
                  value: filter,
                  groupValue: temporaryFilter,
                  onChanged: (value) {
                    if (value == null) return;
                    setDialogState(() => temporaryFilter = value);
                  },
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() => selectedFilter = temporaryFilter);
                Navigator.pop(dialogContext);
              },
              child: const Text('Apply'),
            ),
          ],
        ),
      ),
    );
  }
}
