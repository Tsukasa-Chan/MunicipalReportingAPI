import 'package:flutter/material.dart';

import 'worker_view_reports.dart';
import 'auth_store.dart';
import 'ContactUs.dart';
import 'EditProfile.dart';
import 'Profile.dart';
import 'report_store.dart';
import 'Settings.dart';
import 'StartUp.dart';
import 'worker_theme.dart';

class WorkersDashboardPage extends StatefulWidget {
  const WorkersDashboardPage({super.key});

  @override
  State<WorkersDashboardPage> createState() => _WorkersDashboardPageState();
}

class _WorkersDashboardPageState extends State<WorkersDashboardPage> {
  int _selectedIndex = 0;

  static const _pages = [
    _WorkersOverview(),
    WorkerReportsPage(),
    ContactPage(),
    ProfilePage(),
    SettingsPage(),
    EditProfilePage(),
  ];

  static const _titles = [
    'Worker dashboard',
    'Manage jobs',
    'Contact-us',
    'Profile',
    'Settings',
    'Edit Account',
  ];

  @override
  Widget build(BuildContext context) {
    final worker = AuthStore.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: Image.asset(
                'lib/img/app logo.png',
                width: 42,
                height: 42,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 8),
            Text(_titles[_selectedIndex]),
          ],
        ),
        backgroundColor: const Color(0xFF0B5E8E),
        foregroundColor: Colors.white,
      ),
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              UserAccountsDrawerHeader(
                accountName: Text(
                  '${worker?.name ?? 'Worker'} ${worker?.surname ?? ''}'.trim(),
                ),
                accountEmail: Text(worker?.email ?? 'Job management'),
                currentAccountPicture: const CircleAvatar(
                  backgroundColor: Colors.white,
                  backgroundImage: AssetImage('lib/img/app logo.png'),
                ),
                decoration: BoxDecoration(color: Color(0xFF0B5E8E)),
              ),
              _menuItem(0, Icons.dashboard_outlined, 'Dashboard'),
              _menuItem(1, Icons.fact_check_outlined, 'Manage jobs'),
              _menuItem(2, Icons.contact_mail_outlined, 'Contact-us'),
              _menuItem(3, Icons.person_outline, 'Profile'),
              _menuItem(4, Icons.settings_outlined, 'Settings'),
              _menuItem(5, Icons.edit_outlined, 'Edit Account'),
              const Spacer(),
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Logout'),
                onTap: _logout,
              ),
            ],
          ),
        ),
      ),
      body: const _WorkersOverview(),
    );
  }

  Widget _menuItem(int index, IconData icon, String label) {
    return ListTile(
      selected: _selectedIndex == index,
      selectedColor: const Color(0xFF0B5E8E),
      leading: Icon(icon),
      title: Text(label),
      onTap: () {
        Navigator.pop(context);
        if (index == 0) {
          setState(() => _selectedIndex = 0);
          return;
        }

        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => _pages[index]),
        );
      },
    );
  }

  void _logout() {
    AuthStore.logout();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const StartupPage()),
      (_) => false,
    );
  }
}

class _WorkersOverview extends StatefulWidget {
  const _WorkersOverview();

  @override
  State<_WorkersOverview> createState() => _WorkersOverviewState();
}

class _WorkersOverviewState extends State<_WorkersOverview> {
  @override
  Widget build(BuildContext context) {
    final reports = ReportStore.reports;
    final pending = reports
        .where((report) => report.status == 'Pending')
        .length;
    final inProgress = reports
        .where((report) => report.status == 'In progress')
        .length;
    final onSite = reports.where((report) => report.status == 'On-site').length;
    final finished = reports
        .where((report) => report.status == 'Finished')
        .length;
    return Container(
      decoration: pageBackgroundDecoration(isWorker: true),
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Report activity',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Color(0xFF0B5E8E),
            ),
          ),
          const SizedBox(height: 8),
          const Text('Review incoming reports and keep users informed.'),
          const SizedBox(height: 24),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _StatCard(
                label: 'Total',
                value: reports.length,
                icon: Icons.inbox_outlined,
              ),
              _StatCard(
                label: 'Pending',
                value: pending,
                icon: Icons.pending_actions,
              ),
              _StatCard(
                label: 'In progress',
                value: inProgress,
                icon: Icons.build_circle_outlined,
              ),
              _StatCard(
                label: 'On-site',
                value: onSite,
                icon: Icons.location_on_outlined,
              ),
              _StatCard(
                label: 'Finished',
                value: finished,
                icon: Icons.check_circle_outline,
              ),
            ],
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const WorkerReportsPage()),
            ),
            icon: const Icon(Icons.fact_check_outlined),
            label: const Text('Open report management'),
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF0B5E8E),
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const WorkerReportsPage()),
            ),
            icon: const Icon(Icons.menu_book_outlined),
            label: const Text('Open job logbook'),
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF0B5E8E),
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            '${AuthStore.workers.length} worker(s) registered',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final int value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 155,
      child: Card(
        color: Colors.white.withValues(alpha: 0.88),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: const Color(0xFF0B5E8E)),
              const SizedBox(height: 12),
              Text(
                '$value',
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(label),
            ],
          ),
        ),
      ),
    );
  }
}
