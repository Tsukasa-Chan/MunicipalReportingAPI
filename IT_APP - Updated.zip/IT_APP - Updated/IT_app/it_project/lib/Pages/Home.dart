import 'dart:io';

import 'package:flutter/material.dart';

import 'ContactUs.dart';
import 'EditProfile.dart';
import 'Help.dart';
import 'OtherReports.dart';
import 'Profile.dart';
import 'Reporting.dart';
import 'Settings.dart';
import 'StartUp.dart';
import 'auth_store.dart';
import 'report_store.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final locationController = TextEditingController();
  final addInfoController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _myAreaKey = GlobalKey();
  File? imageIssue;
  final issue = [
    'Potholes',
    'Faulty traffic lights',
    'Broken street lights',
    'Burst water pipes',
    'Road closure',
    'Other',
  ];
  final formKey = GlobalKey<FormState>();

  String? choice;
  String location = '';
  String? additionalInfo;
  final List<String> myAreas = const ['Area 1', 'Area 2', 'Area 3'];
  String selectedArea = 'Area 1';

  final Map<String, List<String>> areaMessages = const {
    'Area 1': [
      'Area 1 is active and ready for updates.',
      'Road maintenance update received for this zone.',
      'Residents reported a new issue near the market square.',
    ],
    'Area 2': [
      'Area 2 has a water repair crew on standby.',
      'Streetlight inspection is scheduled for today.',
      'Community update: drainage check in progress.',
    ],
    'Area 3': [
      'Area 3 is monitoring recent complaints.',
      'Waste collection team has been notified.',
      'Public safety team is reviewing the latest reports.',
    ],
  };

  final areaReportCounts = const {
    'Water': 1,
    'Road': 2,
    'Electricity': 3,
    'Waste': 1,
  };

  DropdownMenuItem<String> buildMenuItem(String item) {
    return DropdownMenuItem<String>(value: item, child: Text(item));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'FIX MY CITY',
              style: TextStyle(color: Colors.white, fontSize: 30),
            ),
            const SizedBox(width: 8),
            ClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(6)),
              child: Image.asset(
                'lib/img/app logo.png',
                width: 42,
                height: 42,
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
        centerTitle: true,
        backgroundColor: Colors.red,
        actions: [
          IconButton(
            icon: const Icon(Icons.help, color: Colors.white),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const HelpPage()),
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Colors.red),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.asset(
                      'lib/img/app logo.png',
                      width: 56,
                      height: 56,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'Menu',
                    style: TextStyle(color: Colors.white, fontSize: 25),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Settings'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsPage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('Edit Account'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const EditProfilePage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.phone),
              title: const Text('Contact Us'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ContactPage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.location_on_outlined),
              title: const Text('My Area'),
              onTap: _jumpToMyArea,
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const StartupPage()),
                );
              },
            ),
          ],
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFFB347), Color(0xFFFF7043), Color(0xFFB71C1C)],
          ),
        ),
        child: SingleChildScrollView(
          controller: _scrollController,
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              _buildAreaStatistics(context),
              const SizedBox(height: 20),
              _buildMyAreaSection(),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 1,
        backgroundColor: Colors.red,
        selectedItemColor: Colors.white,
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const OtherReportsPage()),
            );
          } else if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ReportingPage()),
            );
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ProfilePage()),
            );
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.assignment),
            label: 'View Complaints',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.add), label: 'New Report'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  void _jumpToMyArea() {
    Navigator.pop(context);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) {
        return;
      }

      final maxScroll = _scrollController.position.maxScrollExtent;
      if (maxScroll > 0) {
        _scrollController.animateTo(
          maxScroll,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  Widget _buildMyAreaSection() {
    return Container(
      key: _myAreaKey,
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.88),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'My Area',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                isExpanded: true,
                value: selectedArea,
                items: myAreas
                    .map(
                      (area) => DropdownMenuItem<String>(
                        value: area,
                        child: Text(area),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  if (value == null) return;

                  setState(() => selectedArea = value);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AreaDetailPage(areaName: value),
                    ),
                  );
                },
              ),
            ),
          ),
          const SizedBox(height: 18),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFF5F5F5),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.chat_bubble_outline, color: Colors.red),
                    const SizedBox(width: 8),
                    Text(
                      'Chat for $selectedArea',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ...areaMessages[selectedArea]!.map(
                  (message) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Text(message),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAreaStatistics(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.86),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Statistics of Area',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'DESAINAGAR',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 22),
          const Text(
            'Problems in area',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          _statRow(
            context,
            label: 'Water',
            count: areaReportCounts['Water']!,
            filter: 'Water and Sanitation',
            icon: Icons.water_drop_outlined,
            color: Colors.blue,
          ),
          _statRow(
            context,
            label: 'Road',
            count: areaReportCounts['Road']!,
            filter: 'Roads and Stormwater',
            icon: Icons.alt_route,
            color: const Color(0xFFB71C1C),
          ),
          _statRow(
            context,
            label: 'Electricity',
            count: areaReportCounts['Electricity']!,
            filter: 'Electricity',
            icon: Icons.bolt,
            color: Colors.blueGrey,
          ),
          _statRow(
            context,
            label: 'Waste',
            count: areaReportCounts['Waste']!,
            filter: 'Waste Management',
            icon: Icons.delete_outline,
            color: Colors.teal,
          ),
        ],
      ),
    );
  }

  Widget _statRow(
    BuildContext context, {
    required String label,
    required int count,
    required String filter,
    required IconData icon,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Material(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => OtherReportsPage(initialFilter: filter),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            child: Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Text(
                  '$count reports',
                  style: TextStyle(color: color, fontWeight: FontWeight.bold),
                ),
                const SizedBox(width: 6),
                const Icon(Icons.chevron_right),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    locationController.dispose();
    addInfoController.dispose();
    super.dispose();
  }
}

class AreaDetailPage extends StatefulWidget {
  const AreaDetailPage({super.key, required this.areaName});

  final String areaName;

  @override
  State<AreaDetailPage> createState() => _AreaDetailPageState();
}

class _AreaDetailPageState extends State<AreaDetailPage> {
  final TextEditingController _messageController = TextEditingController();
  late final List<String> _participants;
  late final List<Map<String, String>> _messages;

  @override
  void initState() {
    super.initState();

    final currentUser = AuthStore.currentUser;
    final currentName = currentUser == null
        ? 'Guest User'
        : '${currentUser.name} ${currentUser.surname}'.trim();
    final otherUsers = AuthStore.workers
        .map((user) => '${user.name} ${user.surname}'.trim())
        .where((name) => name.isNotEmpty && name != currentName)
        .toList();

    _participants = [currentName, ...otherUsers];
    _messages = [
      {
        'sender': 'System',
        'text':
            'Welcome to ${widget.areaName}. Your profile credentials were used to join this area chat.',
      },
      {
        'sender': currentName,
        'text': 'I am online and ready to help in ${widget.areaName}.',
      },
    ];
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = AuthStore.currentUser;
    final currentName = currentUser == null
        ? 'Guest User'
        : '${currentUser.name} ${currentUser.surname}'.trim();

    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.red, title: Text(widget.areaName)),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFFB347), Color(0xFFFF7043), Color(0xFFB71C1C)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.92),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Reports for ${widget.areaName}',
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Area updates and the latest reports are grouped here for quick access.',
                        style: TextStyle(color: Colors.black87),
                      ),
                      const SizedBox(height: 18),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    AreaReportsPage(areaName: widget.areaName),
                              ),
                            );
                          },
                          icon: const Icon(Icons.assignment_turned_in),
                          label: Text('Reports for ${widget.areaName}'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 18,
                              vertical: 12,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.92),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(
                            Icons.chat_bubble_outline,
                            color: Colors.red,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Chat room • ${widget.areaName}',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Automatically added members',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _participants
                            .map(
                              (participant) => Chip(
                                label: Text(participant),
                                backgroundColor: participant == currentName
                                    ? Colors.red.shade100
                                    : Colors.grey.shade200,
                              ),
                            )
                            .toList(),
                      ),
                      const SizedBox(height: 16),
                      ConstrainedBox(
                        constraints: const BoxConstraints(minHeight: 180),
                        child: ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _messages.length,
                          itemBuilder: (context, index) {
                            final message = _messages[index];
                            final isCurrentUser =
                                message['sender'] == currentName;
                            return Align(
                              alignment: isCurrentUser
                                  ? Alignment.centerRight
                                  : Alignment.centerLeft,
                              child: Container(
                                margin: const EdgeInsets.only(bottom: 8),
                                padding: const EdgeInsets.all(12),
                                constraints: const BoxConstraints(
                                  maxWidth: 260,
                                ),
                                decoration: BoxDecoration(
                                  color: isCurrentUser
                                      ? Colors.red
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: isCurrentUser
                                        ? Colors.red
                                        : Colors.grey.shade300,
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      message['sender'] ?? 'User',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: isCurrentUser
                                            ? Colors.white
                                            : Colors.black87,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      message['text'] ?? '',
                                      style: TextStyle(
                                        color: isCurrentUser
                                            ? Colors.white
                                            : Colors.black87,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _messageController,
                              decoration: const InputDecoration(
                                hintText: 'Message this area',
                                filled: true,
                                fillColor: Colors.white,
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            onPressed: () {
                              final message = _messageController.text.trim();
                              if (message.isEmpty) return;

                              setState(() {
                                _messages.add({
                                  'sender': currentName,
                                  'text': message,
                                });
                                _messageController.clear();
                              });
                            },
                            icon: const Icon(Icons.send, color: Colors.red),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }
}

class AreaReportsPage extends StatelessWidget {
  const AreaReportsPage({super.key, required this.areaName});

  final String areaName;

  @override
  Widget build(BuildContext context) {
    final areaReports = ReportStore.reportsForArea(areaName);

    return Scaffold(
      appBar: AppBar(
        title: Text('Reports for $areaName'),
        backgroundColor: Colors.red,
      ),
      body: Container(
        padding: const EdgeInsets.all(16),
        color: const Color(0xFFF5F5F5),
        child: areaReports.isEmpty
            ? Center(
                child: Text(
                  'No reports available for $areaName yet.',
                  style: const TextStyle(fontSize: 18),
                ),
              )
            : ListView.builder(
                itemCount: areaReports.length,
                itemBuilder: (context, index) {
                  final report = areaReports[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: Colors.red,
                        child: Icon(Icons.assignment, color: Colors.white),
                      ),
                      title: Text(report.issueType),
                      subtitle: Text(
                        '${report.issue}\nSubmitted by ${report.senderName}',
                      ),
                      isThreeLine: true,
                    ),
                  );
                },
              ),
      ),
    );
  }
}
