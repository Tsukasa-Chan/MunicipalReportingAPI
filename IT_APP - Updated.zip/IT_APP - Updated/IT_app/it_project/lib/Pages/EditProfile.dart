import 'package:flutter/material.dart';

import 'Help.dart';
import 'auth_store.dart';
import 'worker_theme.dart';

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final nameController = TextEditingController(text: 'User 1');
  final emailController = TextEditingController(text: 'user1@gmail.com');
  final currentPasswordController = TextEditingController();
  final newPasswordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final isWorker = AuthStore.currentUser?.isWorker == true;
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: pagePrimaryColor(isWorker: isWorker),
        title: const Text(
          'Edit Profile',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          tooltip: 'Back',
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            tooltip: 'Help',
            icon: const Icon(Icons.help_outline, color: Colors.white),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HelpPage()),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: pageBackgroundDecoration(isWorker: isWorker),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Center(
                  child: CircleAvatar(
                    radius: 48,
                    backgroundColor: Color(0xFF0B5E8E),
                    child: Icon(Icons.person, size: 50, color: Colors.white),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Edit your profile',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 24),
                _profileCard(
                  icon: Icons.person_outline,
                  label: 'Name',
                  value: nameController.text,
                  onTap: _showNameDialog,
                ),
                _profileCard(
                  icon: Icons.email_outlined,
                  label: 'Email',
                  value: emailController.text,
                  onTap: _showEmailDialog,
                ),
                _profileCard(
                  icon: Icons.lock_outline,
                  label: 'Password',
                  value: 'Change your password',
                  onTap: _showPasswordDialog,
                ),
                const SizedBox(height: 20),
                OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: const BorderSide(color: Colors.white),
                    minimumSize: const Size.fromHeight(52),
                  ),
                  child: const Text('Done'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _profileCard({
    required IconData icon,
    required String label,
    required String value,
    required VoidCallback onTap,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      color: Colors.white.withValues(alpha: 0.82),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
        leading: Icon(icon, color: const Color(0xFF0B5E8E)),
        title: Text(
          label,
          style: const TextStyle(
            color: Color(0xFF0B5E8E),
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          value,
          style: const TextStyle(
            color: Color(0xFF1F1F1F),
            fontSize: 17,
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }

  Future<void> _showNameDialog() async {
    final controller = TextEditingController(text: nameController.text);
    await _showSingleFieldDialog(
      title: 'Edit name',
      label: 'Name',
      controller: controller,
      requiresVerification: true,
      verificationTitle: 'Verify name change',
      verificationMessage: 'Confirm that you want to update your name.',
      onSave: () {
        if (controller.text.trim().isEmpty) return false;
        setState(() => nameController.text = controller.text.trim());
        return true;
      },
    );
    controller.dispose();
  }

  Future<void> _showEmailDialog() async {
    final controller = TextEditingController(text: emailController.text);
    await _showSingleFieldDialog(
      title: 'Edit email',
      label: 'Email',
      controller: controller,
      keyboardType: TextInputType.emailAddress,
      requiresVerification: true,
      verificationTitle: 'Verify email change',
      verificationMessage:
          'Confirm that you want to use this verified email address.',
      onSave: () {
        final email = controller.text.trim().toLowerCase();
        if (!RegExp(
          r'^[^\s@]+@(gmail|yahoo|outlook|hotmail|live|microsoft)\.com$',
          caseSensitive: false,
        ).hasMatch(email)) {
          return false;
        }
        setState(() => emailController.text = email);
        return true;
      },
    );
    controller.dispose();
  }

  Future<void> _showSingleFieldDialog({
    required String title,
    required String label,
    required TextEditingController controller,
    required bool Function() onSave,
    bool requiresVerification = false,
    String verificationTitle = 'Verify change',
    String verificationMessage = 'Confirm this account change.',
    TextInputType? keyboardType,
  }) async {
    final formKey = GlobalKey<FormState>();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Form(
          key: formKey,
          child: TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return 'Please enter a value';
              }
              if (keyboardType == TextInputType.emailAddress &&
                  !RegExp(
                    r'^[^\s@]+@(gmail|yahoo|outlook|hotmail|live|microsoft)\.com$',
                    caseSensitive: false,
                  ).hasMatch(value.trim().toLowerCase())) {
                return 'Use a Gmail, Yahoo, Outlook, or Microsoft email';
              }
              return null;
            },
            decoration: InputDecoration(labelText: label),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              if (requiresVerification) {
                final verified = await _showVerificationDialog(
                  title: verificationTitle,
                  message: verificationMessage,
                );
                if (!verified || !mounted) return;
              }
              if (onSave()) {
                if (!mounted) return;
                Navigator.pop(dialogContext);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Profile updated.')),
                );
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _showPasswordDialog() async {
    final formKey = GlobalKey<FormState>();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Change password'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _passwordField(
                  currentPasswordController,
                  'Current password',
                  false,
                ),
                const SizedBox(height: 12),
                _passwordField(newPasswordController, 'New password', true),
                const SizedBox(height: 12),
                _passwordField(
                  confirmPasswordController,
                  'Confirm password',
                  true,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (formKey.currentState!.validate()) {
                final verified = await _showVerificationDialog(
                  title: 'Verify password change',
                  message:
                      'Your new password meets the required security rules.',
                );
                if (!verified || !mounted) return;
                Navigator.pop(dialogContext);
                currentPasswordController.clear();
                newPasswordController.clear();
                confirmPasswordController.clear();
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Password changed successfully.'),
                  ),
                );
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<bool> _showVerificationDialog({
    required String title,
    required String message,
  }) async {
    return await showDialog<bool>(
          context: context,
          builder: (verificationContext) => AlertDialog(
            title: Text(title),
            content: Text(message),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(verificationContext, false),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(verificationContext, true),
                child: const Text('Verify'),
              ),
            ],
          ),
        ) ??
        false;
  }

  TextFormField _passwordField(
    TextEditingController controller,
    String label,
    bool validateSecurity,
  ) {
    return TextFormField(
      controller: controller,
      obscureText: true,
      validator: (value) {
        final password = value ?? '';
        if (password.isEmpty) return 'Please enter $label';
        if (validateSecurity) {
          if (password.length < 8) {
            return 'Password must be 8 characters or more';
          }
          if (!RegExp(r'[A-Z]').hasMatch(password) ||
              !RegExp(r'[a-z]').hasMatch(password) ||
              !RegExp(r'[0-9]').hasMatch(password)) {
            return 'Use uppercase, lowercase, and a number';
          }
          if (!RegExp(r'^[A-Za-z0-9@#_]+$').hasMatch(password)) {
            return 'Only letters, numbers, @, #, and _ are allowed';
          }
        }
        return null;
      },
      decoration: InputDecoration(labelText: label),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    currentPasswordController.dispose();
    newPasswordController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }
}
