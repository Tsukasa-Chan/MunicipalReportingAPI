import 'package:flutter/material.dart';

import 'ContactUs.dart';
import 'EditProfile.dart';
import 'Help.dart';
import 'OtherReports.dart';
import 'auth_store.dart';
import 'worker_theme.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final scrollController = ScrollController();

  final reports = [
    {
      'id': '001',
      'issue': 'Roads and Stormwater',
      'specificIssue': 'Pothole',
      'addInfo':
          'There are multiple potholes on this road, on the oncoming lanes as well',
      'location': '20 Dolphin Road',
      'date': '17/05/2026',
      'status': 'Pending',
    },
    {
      'id': '002',
      'issue': 'Electricity',
      'specificIssue': 'Street Light Not Working',
      'addInfo': '',
      'location': '50 King Shaka Road',
      'date': '02/07/2026',
      'status': 'Pending',
    },
    {
      'id': '003',
      'issue': 'Water and Sanitation',
      'specificIssue': 'No Water Supply',
      'addInfo': '',
      'location': '50 King Shaka Road',
      'date': '02/07/2026',
      'status': 'Pending',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final user = AuthStore.currentUser;
    final isWorker = user?.isWorker == true;
    final displayName = user == null
        ? 'User'
        : '${user.name} ${user.surname}'.trim();
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: pagePrimaryColor(isWorker: isWorker),
        title: const Text(
          'Profile',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          tooltip: 'Back',
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            tooltip: 'Help',
            icon: const Icon(Icons.help_outline, color: Colors.white),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HelpPage()),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: pageBackgroundDecoration(isWorker: isWorker),
        child: SafeArea(
          child: SingleChildScrollView(
            controller: scrollController,
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Center(
                  child: CircleAvatar(
                    radius: 48,
                    backgroundColor: Color(0xFF0B5E8E),
                    child: Icon(Icons.person, size: 50, color: Colors.white),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        displayName,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Edit profile',
                      icon: const Icon(Icons.edit, color: Colors.white),
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const EditProfilePage(),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _InfoCard(
                  label: 'Username',
                  value: user?.username ?? 'Not set',
                ),
                _InfoCard(label: 'Email', value: user?.email ?? 'Not set'),
                _InfoCard(
                  label: 'Verification',
                  value: user?.isVerified == true ? 'Verified' : 'Not verified',
                ),
                const SizedBox(height: 18),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    _quickLink(
                      context,
                      label: 'View Reports',
                      icon: Icons.assignment,
                      page: const OtherReportsPage(),
                    ),
                    _quickLink(
                      context,
                      label: 'Contact Us',
                      icon: Icons.contact_mail,
                      page: const ContactPage(),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                const Text(
                  'Your Recent Reports',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                ...reports.map(_reportCard),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'Back to top',
        backgroundColor: pagePrimaryColor(isWorker: isWorker),
        onPressed: () => scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeOutCubic,
        ),
        child: const Icon(Icons.arrow_upward, color: Colors.white),
      ),
    );
  }

  Widget _quickLink(
    BuildContext context, {
    required String label,
    required IconData icon,
    required Widget page,
  }) {
    return ElevatedButton.icon(
      onPressed: () =>
          Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
      icon: Icon(icon),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF0B5E8E),
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
    );
  }

  Widget _reportCard(Map<String, String> report) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        title: Text('Report #${report['id']} - ${report['issue']}'),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        children: [
          _reportDetail('Status', report['status'] ?? 'No status'),
          _reportDetail('Date Submitted', report['date'] ?? 'No date'),
          _reportDetail('Specific Issue', report['specificIssue'] ?? 'Unknown'),
          _reportDetail('Location', report['location'] ?? 'Unknown'),
          _reportDetail('Additional Information', report['addInfo'] ?? 'None'),
        ],
      ),
    );
  }

  Widget _reportDetail(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text('$label: $value'),
      ),
    );
  }

  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.82),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF0B5E8E),
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              color: Color(0xFF1F1F1F),
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
