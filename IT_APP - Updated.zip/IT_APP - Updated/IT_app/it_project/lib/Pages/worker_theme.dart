import 'package:flutter/material.dart';

const workerPrimaryColor = Color(0xFF0B5E8E);
const userPrimaryColor = Color(0xFFB71C1C);

Color pagePrimaryColor({required bool isWorker}) =>
    isWorker ? workerPrimaryColor : userPrimaryColor;

BoxDecoration pageBackgroundDecoration({required bool isWorker}) {
  return BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: isWorker
          ? const [Color(0xFFC9F7B6), Color(0xFF2DEB2A)]
          : const [Color(0xFFFFB347), Color(0xFFFF7043), Color(0xFFB71C1C)],
    ),
  );
}
