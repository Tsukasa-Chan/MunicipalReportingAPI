import 'dart:convert';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'auth_store.dart';

class ReportRequest {
  ReportRequest({
    required this.id,
    required this.senderName,
    required this.issueType,
    required this.issue,
    required this.area,
    this.imagePath = '',
    DateTime? createdAt,
    DateTime? queuedAt,
    this.submittedAt,
    this.syncStatus = 'Pending sync',
    this.description = '',
    this.status = 'Pending',
    this.invoiceNumber,
    this.workerName = '',
    this.workerId = '',
    this.jobNumber = '',
    this.locationAddress = '',
    this.pinLocation = '',
    this.startTime = '',
    this.stopTime = '',
    this.totalTime = '',
    this.managerSignature = '',
    this.workerSignature = '',
    this.storageType = 'online',
  }) : createdAt = createdAt ?? DateTime.now(),
       queuedAt = queuedAt ?? createdAt ?? DateTime.now();

  final int id;
  final String senderName;
  String issueType;
  String issue;
  String area;
  String imagePath;
  final DateTime createdAt;
  final DateTime queuedAt;
  DateTime? submittedAt;
  String syncStatus;
  String description;
  String status;
  String? invoiceNumber;
  String workerName;
  String workerId;
  String jobNumber;
  String locationAddress;
  String pinLocation;
  String startTime;
  String stopTime;
  String totalTime;
  String managerSignature;
  String workerSignature;
  String storageType;

  bool get isOffline => storageType == 'offline';
  bool get isSubmitted => submittedAt != null;

  void markSubmitted() {
    submittedAt = DateTime.now();
    syncStatus = 'Synced';
    status = status.isEmpty ? 'Pending' : status;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'senderName': senderName,
    'issueType': issueType,
    'issue': issue,
    'area': area,
    'imagePath': imagePath,
    'createdAt': createdAt.toIso8601String(),
    'queuedAt': queuedAt.toIso8601String(),
    'submittedAt': submittedAt?.toIso8601String(),
    'syncStatus': syncStatus,
    'storageType': storageType,
    'description': description,
    'status': status,
    'invoiceNumber': invoiceNumber,
    'workerName': workerName,
    'workerId': workerId,
    'jobNumber': jobNumber,
    'locationAddress': locationAddress,
    'pinLocation': pinLocation,
    'startTime': startTime,
    'stopTime': stopTime,
    'totalTime': totalTime,
    'managerSignature': managerSignature,
    'workerSignature': workerSignature,
  };

  factory ReportRequest.fromJson(Map<String, dynamic> json) => ReportRequest(
    id: json['id'] as int,
    senderName: json['senderName'] as String,
    issueType: json['issueType'] as String,
    issue: json['issue'] as String,
    area: json['area'] as String,
    imagePath: json['imagePath'] as String? ?? '',
    createdAt: DateTime.parse(json['createdAt'] as String),
    queuedAt:
        DateTime.tryParse(json['queuedAt'] as String? ?? '') ?? DateTime.now(),
    submittedAt: json['submittedAt'] == null
        ? null
        : DateTime.tryParse(json['submittedAt'] as String),
    syncStatus: json['syncStatus'] as String? ?? 'Pending sync',
    description: json['description'] as String? ?? '',
    status: json['status'] as String? ?? 'Pending',
    invoiceNumber: json['invoiceNumber'] as String?,
    workerName: json['workerName'] as String? ?? '',
    workerId: json['workerId'] as String? ?? '',
    jobNumber: json['jobNumber'] as String? ?? '',
    locationAddress: json['locationAddress'] as String? ?? '',
    pinLocation: json['pinLocation'] as String? ?? '',
    startTime: json['startTime'] as String? ?? '',
    stopTime: json['stopTime'] as String? ?? '',
    totalTime: json['totalTime'] as String? ?? '',
    managerSignature: json['managerSignature'] as String? ?? '',
    workerSignature: json['workerSignature'] as String? ?? '',
    storageType: json['storageType'] as String? ?? 'online',
  );
}

class ReportStore {
  static const _storageKey = 'offline_reports';
  static final List<ReportRequest> _reports = [];
  static int _nextId = 1;
  static SharedPreferences? _preferences;
  static bool _isOnline = true;

  static bool get isOnline => _isOnline;

  static void setConnectionStatus(bool isOnline) {
    _isOnline = isOnline;
  }

  static Future<void> initialize() async {
    try {
      final connectivity = Connectivity();
      final initialStatus = await connectivity.checkConnectivity();
      _isOnline = initialStatus != ConnectivityResult.none;
      connectivity.onConnectivityChanged.listen((result) {
        _isOnline = result != ConnectivityResult.none;
      });
    } catch (_) {
      _isOnline = true;
    }

    _preferences = await SharedPreferences.getInstance();
    final storedReports = _preferences!.getStringList(_storageKey) ?? [];
    _reports
      ..clear()
      ..addAll(
        storedReports.map(
          (value) =>
              ReportRequest.fromJson(jsonDecode(value) as Map<String, dynamic>),
        ),
      );
    if (_reports.isNotEmpty) {
      _nextId =
          _reports
              .map((report) => report.id)
              .reduce((first, second) => first > second ? first : second) +
          1;
    }
  }

  static List<ReportRequest> get reports => List.unmodifiable(_reports);
  static List<ReportRequest> get offlineReports => List.unmodifiable(
    _reports.where((report) => report.storageType == 'offline').toList(),
  );
  static List<ReportRequest> get onlineReports => List.unmodifiable(
    _reports.where((report) => report.storageType == 'online').toList(),
  );

  static Map<String, dynamic> analyticsSummary() {
    final totalReports = _reports.length;
    final syncedReports = _reports
        .where((report) => report.syncStatus == 'Synced')
        .length;
    final offlineReports = _reports
        .where((report) => report.storageType == 'offline')
        .length;
    final onlineReports = _reports
        .where((report) => report.storageType == 'online')
        .length;
    final pendingReports = _reports
        .where((report) => report.syncStatus != 'Synced')
        .length;

    return {
      'totalReports': totalReports,
      'syncedReports': syncedReports,
      'offlineReports': offlineReports,
      'onlineReports': onlineReports,
      'pendingReports': pendingReports,
    };
  }

  static List<ReportRequest> reportsForArea(String area) {
    final normalizedArea = area.trim().toLowerCase();
    final areaReports =
        _reports
            .where(
              (report) => report.area.trim().toLowerCase() == normalizedArea,
            )
            .toList()
          ..sort((first, second) => second.id.compareTo(first.id));
    return List.unmodifiable(areaReports);
  }

  static ReportRequest? addReport({
    required String issueType,
    required String issue,
    required String area,
    String description = '',
    String pinLocation = '',
    String locationAddress = '',
    required String imagePath,
    bool isOfflineSubmission = false,
  }) {
    final user = AuthStore.currentUser;
    if (user == null) {
      return null;
    }

    final report = ReportRequest(
      id: _nextId++,
      senderName: '${user.name} ${user.surname}',
      issueType: issueType,
      issue: issue,
      area: area.trim(),
      description: description.trim(),
      pinLocation: pinLocation.trim(),
      locationAddress: locationAddress.trim(),
      storageType: 'offline',
      syncStatus: 'Queued offline',
      queuedAt: DateTime.now(),
      createdAt: DateTime.now(),
      submittedAt: null,
    );
    _reports.insert(0, report);
    _save();
    return report;
  }

  static List<ReportRequest> get pendingSyncReports => List.unmodifiable(
    _reports
        .where(
          (report) =>
              report.storageType == 'offline' && report.syncStatus != 'Synced',
        )
        .toList(),
  );

  static Future<void> syncPendingReports(
    Future<bool> Function(ReportRequest report) sendReport,
  ) async {
    for (final report in pendingSyncReports.toList()) {
      if (await sendReport(report)) {
        report.storageType = 'online';
        report.markSubmitted();
      }
    }
    await _save();
  }

  static void updateStatus(ReportRequest report, String status) {
    report.status = status;
    _save();
  }

  static void updateReport({
    required ReportRequest report,
    required String issueType,
    required String issue,
    required String description,
  }) {
    report.issueType = issueType;
    report.issue = issue;
    report.description = description.trim();
    _save();
  }

  static void saveJobCompletion({
    required ReportRequest report,
    required String workerName,
    required String workerId,
    required String jobNumber,
    required String locationAddress,
    required String pinLocation,
    required String startTime,
    required String stopTime,
    required String totalTime,
    required String managerSignature,
    required String workerSignature,
  }) {
    report.invoiceNumber ??= 'LOG-${report.id.toString().padLeft(4, '0')}';
    report.workerName = workerName.trim();
    report.workerId = workerId.trim();
    report.jobNumber = jobNumber.trim();
    report.locationAddress = locationAddress.trim();
    report.pinLocation = pinLocation.trim();
    report.startTime = startTime.trim();
    report.stopTime = stopTime.trim();
    report.totalTime = totalTime.trim();
    report.managerSignature = managerSignature.trim();
    report.workerSignature = workerSignature.trim();
    report.status = 'Finished';
    _save();
  }

  static Future<void> _save() async {
    final preferences = _preferences;
    if (preferences == null) return;
    await preferences.setStringList(
      _storageKey,
      _reports.map((report) => jsonEncode(report.toJson())).toList(),
    );
  }
}
