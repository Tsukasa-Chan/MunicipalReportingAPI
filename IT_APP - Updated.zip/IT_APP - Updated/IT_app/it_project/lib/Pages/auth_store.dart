class UserAccount {
  const UserAccount({
    required this.name,
    required this.surname,
    required this.username,
    required this.email,
    required this.password,
    this.isAdmin = false,
    this.isWorker = false,
    this.isVerified = false,
  });

  final String name;
  final String surname;
  final String username;
  final String email;
  final String password;
  final bool isAdmin;
  final bool isWorker;
  final bool isVerified;

  UserAccount copyWith({
    String? name,
    String? surname,
    String? username,
    String? email,
    String? password,
    bool? isAdmin,
    bool? isWorker,
    bool? isVerified,
  }) {
    return UserAccount(
      name: name ?? this.name,
      surname: surname ?? this.surname,
      username: username ?? this.username,
      email: email ?? this.email,
      password: password ?? this.password,
      isAdmin: isAdmin ?? this.isAdmin,
      isWorker: isWorker ?? this.isWorker,
      isVerified: isVerified ?? this.isVerified,
    );
  }
}

class AuthStore {
  static final Map<String, UserAccount> _users = {
    'user': const UserAccount(
      name: 'User',
      surname: '',
      username: 'user',
      email: 'user123@gmail.com',
      password: 'Root_user123',
      isVerified: true,
    ),
    'shalin': const UserAccount(
      name: 'Shalin',
      surname: 'Govender',
      username: 'shalin',
      email: 'shaling357@gmail.com',
      password: 'Smg_22@7',
      isAdmin: true,
      isWorker: true,
      isVerified: true,
    ),
  };
  static final Map<String, List<String>> _savedAreas = {};
  static String? _currentUsername;

  static UserAccount? get currentUser {
    final username = _currentUsername;
    return username == null ? null : _users[username];
  }

  static void logout() {
    _currentUsername = null;
  }

  static List<String> get savedAreas {
    final username = _currentUsername;
    if (username == null) {
      return const [];
    }
    return List.unmodifiable(_savedAreas[username] ?? const []);
  }

  static bool addSavedArea(String area) {
    final username = _currentUsername;
    final cleanArea = area.trim();
    if (username == null || cleanArea.isEmpty) {
      return false;
    }
    final areas = _savedAreas.putIfAbsent(username, () => []);
    if (areas.any(
      (savedArea) => savedArea.toLowerCase() == cleanArea.toLowerCase(),
    )) {
      return false;
    }
    areas.add(cleanArea);
    return true;
  }

  static void removeSavedArea(String area) {
    final username = _currentUsername;
    if (username == null) {
      return;
    }
    _savedAreas[username]?.remove(area);
  }

  static void registerUser({
    required String name,
    required String surname,
    required String username,
    required String email,
    required String password,
    bool isWorker = false,
  }) {
    final cleanUsername = username.trim();
    if (cleanUsername.isEmpty) {
      return;
    }

    final normalizedEmail = email.trim();
    _users[cleanUsername] = UserAccount(
      name: name.trim(),
      surname: surname.trim(),
      username: cleanUsername,
      email: normalizedEmail,
      password: password,
      isWorker: isWorker,
    );
    _currentUsername = cleanUsername;
  }

  static bool validateLogin({
    required String username,
    required String password,
  }) {
    final cleanUsername = username.trim();
    UserAccount? user = _users[cleanUsername];
    user ??= _users.values.cast<UserAccount?>().firstWhere(
      (candidate) =>
          candidate?.email.toLowerCase() == cleanUsername.toLowerCase(),
      orElse: () => null,
    );
    final isValid = user != null && user.password == password;
    if (isValid) {
      _currentUsername = user.username;
    }
    return isValid;
  }

  static bool userExists(String username) {
    return _users.containsKey(username.trim());
  }

  static UserAccount? findUser(String username) {
    return _users[username.trim()];
  }

  static List<UserAccount> get workers =>
      _users.values.where((user) => user.isWorker).toList(growable: false);

  static bool addWorker({
    required String name,
    required String surname,
    required String username,
    required String email,
    required String password,
  }) {
    if (currentUser?.isWorker != true && currentUser?.isAdmin != true) {
      return false;
    }

    final cleanUsername = username.trim();
    if (cleanUsername.isEmpty || _users.containsKey(cleanUsername)) {
      return false;
    }

    _users[cleanUsername] = UserAccount(
      name: name.trim(),
      surname: surname.trim(),
      username: cleanUsername,
      email: email.trim(),
      password: password,
      isWorker: true,
      isVerified: true,
    );
    return true;
  }

  static void updateCurrentUser({
    required String name,
    required String surname,
    required String email,
  }) {
    final username = _currentUsername;
    if (username == null) {
      return;
    }

    final existing = _users[username];
    if (existing == null) {
      return;
    }

    _users[username] = existing.copyWith(
      name: name.trim(),
      surname: surname.trim(),
      email: email.trim(),
    );
  }

  static void resetPassword(String username, String newPassword) {
    final cleanUsername = username.trim();
    final existing = _users[cleanUsername];
    if (existing == null) {
      return;
    }

    _users[cleanUsername] = existing.copyWith(password: newPassword);
  }

  static void markVerified(String username) {
    final cleanUsername = username.trim();
    final existing = _users[cleanUsername];
    if (existing == null) {
      return;
    }

    _users[cleanUsername] = existing.copyWith(isVerified: true);
  }

  static String maskEmail(String email) {
    final trimmed = email.trim();
    if (!trimmed.contains('@')) {
      return trimmed;
    }

    final atIndex = trimmed.indexOf('@');
    final localPart = trimmed.substring(0, atIndex);
    final domain = trimmed.substring(atIndex);

    if (localPart.length <= 4) {
      return '${localPart.substring(0, localPart.length)}****$domain';
    }

    return '${localPart.substring(0, 3)}****${localPart.substring(localPart.length - 3)}$domain';
  }
}
